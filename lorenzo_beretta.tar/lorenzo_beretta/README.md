SPM2020 project, Lorenzo Beretta, 536242

This folder contains all you need to run the two requested implementations, entirely coded into pthread-async.cpp and ff-farm.cpp. More file are present only because they are cited in the report, however they are not supposed to be compiled and run, but only as an example of previous tentative patterns. A sequential implementation is also present.

This folder contains a Makefile that should run smoothly on the Xeon Phi machine whose access has been provided to students; to build all the file it will be sufficient to run "make all". Tu run the single programs it is enough to launch them and a brief help will explain which arguments to provide.